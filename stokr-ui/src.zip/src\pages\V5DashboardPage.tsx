import { useSessionStore } from "../state/session";
import { cn } from "../lib/utils";

export function V5DashboardPage() {
  const username = useSessionStore((s) => s.username);
  const roles = useSessionStore((s) => s.roles);
  const email = useSessionStore((s) => s.email);
  const emailVerified = useSessionStore((s) => s.emailVerified);
  const isAdmin = roles.includes("ROLE_ADMIN");

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Welcome back, {username || "trader"}</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border bg-card p-4 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium">Account</h3>
          <p className="mt-2 text-2xl font-bold">Active</p>
          <p className="mt-1 text-xs text-muted-foreground">{email}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium">Role</h3>
          <p className="mt-2 text-2xl font-bold">{isAdmin ? "Admin" : "Trader"}</p>
          <p className="mt-1 text-xs text-muted-foreground">{roles.join(", ")}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium">Email</h3>
          <p className={cn("mt-2 text-2xl font-bold", emailVerified ? "text-green-600" : "text-yellow-600")}>{emailVerified ? "Verified" : "Pending"}</p>
        </div>
        <div className="rounded-lg border bg-card p-4 text-card-foreground shadow-sm">
          <h3 className="text-sm font-medium">System</h3>
          <p className="mt-2 text-2xl font-bold">v5</p>
          <p className="mt-1 text-xs text-green-600">UP</p>
        </div>
      </div>
    </div>
  );
}

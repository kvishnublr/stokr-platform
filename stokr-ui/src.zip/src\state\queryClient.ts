import { QueryClient } from "@tanstack/react-query";

/** Shared defaults: fewer redundant refetches → faster perceived navigation. */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 20_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});
